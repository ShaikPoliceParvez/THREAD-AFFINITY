compile:

g++ -o Assign2_Mixed_Src-cs22btech11052 Assign2_Mixed_Src-cs22btech11052.cpp -pthread

g++ -o Assign2_Chunk_Src-cs22btech11052 Assign2_Chunk_Src-cs22btech11052.cpp -pthread


executing/ running:

./mixed

./chunk