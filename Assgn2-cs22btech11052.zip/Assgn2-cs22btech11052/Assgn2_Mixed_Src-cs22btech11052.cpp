#include <iostream>
#include <fstream>
#include <vector>
#include <chrono>
#include <pthread.h>
#include <unistd.h>

using namespace std;
using namespace std::chrono;

struct ThreadData {
    const vector<vector<int>>* A;
    vector<vector<int>>* result;
    int start;
    int end;
};

vector<vector<int>> readMatrix(const string& filename, int& N, int& K, int& C, int& BT) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        exit(EXIT_FAILURE);
    }

    file >> N >> K >> C >> BT;

    vector<vector<int>> matrix(N, vector<int>(N));
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            file >> matrix[i][j];
        }
    }

    file.close();
    return matrix;
}

void* computeSquare(void* args) {
    ThreadData* data = static_cast<ThreadData*>(args);
    const vector<vector<int>>& A = *(data->A);
    vector<vector<int>>& result = *(data->result);
    int start = data->start;
    int end = data->end;
    int N = A.size();

    for (int i = start; i < end; ++i) {
        for (int j = 0; j < N; ++j) {
            int sum = 0;
            for (int k = 0; k < N; ++k) {
                sum += A[i][k] * A[k][j];
            }
            result[i][j] = sum;
        }
    }

    pthread_exit(NULL);
}

int main() {
    int N, K, C, BT;
    vector<vector<int>> A = readMatrix("inp.txt", N, K, C, BT);

    vector<vector<int>> result(N, vector<int>(N, 0));

    auto start = high_resolution_clock::now();

    pthread_t threads[K];
    ThreadData threadData[K];

    int boundThreads = 0;
    for (int i = 0; i < K; ++i) {
        int start_row = i % N; // Alternating rows
        int end_row = start_row + 1;

        threadData[i] = {&A, &result, start_row, end_row};

        pthread_create(&threads[i], NULL, computeSquare, &threadData[i]);
        boundThreads++;
    }

    for (int i = 0; i < K; ++i) {
        pthread_join(threads[i], NULL);
    }

    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    double time_taken = duration.count();

    ofstream outfile("out.txt");
    if (!outfile.is_open()) {
        cerr << "Error opening output file: out.txt" << endl;
        exit(EXIT_FAILURE);
    }

    outfile << "Resulting Square Matrix:" << endl;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            outfile << result[i][j] << " ";
        }
        outfile << endl;
    }

    outfile << "Time taken: " << time_taken << " microseconds" << endl;

    outfile.close();

    return 0;
}
